package com.cocautobot

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

private val Bg = Color(0xFF0B0D10)
private val Panel = Color(0xFF171B21)
private val Panel2 = Color(0xFF202630)
private val Gold = Color(0xFFE2B85B)
private val Muted = Color(0xFF9AA3AE)
private val Green = Color(0xFF71C995)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CocApp() }
    }
}

@Composable
fun CocApp() {
    var selected by remember { mutableIntStateOf(0) }
    var ocrStatus by remember { mutableStateOf("لم يتم تحليل صورة بعد") }
    var extracted by remember { mutableStateOf("") }
    val context = androidx.compose.ui.platform.LocalContext.current

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            ocrStatus = "جارٍ تحليل الصورة..."
            try {
                val image = InputImage.fromFilePath(context, uri)
                val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                recognizer.process(image)
                    .addOnSuccessListener { result ->
                        extracted = result.text
                        val numbers = Regex("[0-9][0-9, ]{2,}").findAll(result.text).map { it.value }.toList()
                        ocrStatus = if (numbers.isNotEmpty()) {
                            "اكتمل التحليل — راجع النص والأرقام المستخرجة"
                        } else "لم أتعرف على أرقام واضحة. جرّب صورة أوضح."
                    }
                    .addOnFailureListener { ocrStatus = "تعذر تحليل الصورة: ${it.localizedMessage}" }
            } catch (e: Exception) {
                ocrStatus = "تعذر فتح الصورة: ${e.localizedMessage}"
            }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Gold,
        onBackground = Color.White, onSurface = Color.White, secondary = Green
    )) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    NavigationBarItem(selected == 0, { selected = 0 }, icon = { Icon(Icons.Default.Dashboard, null) }, label = { Text("الرئيسية") })
                    NavigationBarItem(selected == 1, { selected = 1 }, icon = { Icon(Icons.Default.Analytics, null) }, label = { Text("التحليل") })
                    NavigationBarItem(selected == 2, { selected = 2 }, icon = { Icon(Icons.Default.Settings, null) }, label = { Text("الإعدادات") })
                }
            }
        ) { padding ->
            when (selected) {
                0 -> Dashboard(padding, ocrStatus, onImport = { picker.launch("image/*") })
                1 -> AnalysisScreen(padding, extracted, ocrStatus, onImport = { picker.launch("image/*") })
                else -> SettingsScreen(padding)
            }
        }
    }
}

@Composable
fun Dashboard(padding: PaddingValues, status: String, onImport: () -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp),
        contentPadding = PaddingValues(top = 22.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("COC AUTO BOT", color = Gold, fontSize = 22.sp, fontWeight = FontWeight.Black)
                    Text("مركز مراقبة القرية", color = Muted, fontSize = 13.sp)
                }
                Surface(color = Color(0xFF183326), shape = RoundedCornerShape(50)) {
                    Text("● جاهز للتحليل", color = Green, modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp), fontSize = 11.sp)
                }
            }
        }
        item {
            Surface(color = Panel, shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Text("ملخص القرية", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text("المستوى 62  •  بيانات آخر صورة أرسلتها", color = Muted, fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ResourceTile("الذهب", "1,199,900", "✦", Gold, Modifier.weight(1f))
                        ResourceTile("الإكسير", "759,712", "●", Color(0xFFCA76F2), Modifier.weight(1f))
                    }
                    ResourceTile("الإكسير الأسود", "62,430", "◆", Color(0xFF9EA5B1), Modifier.fillMaxWidth())
                    Text("الجواهر: 5     •     البنّاؤون: 1/6", color = Muted, fontSize = 12.sp)
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricCard("سعة الجيش", "220 / 220", Icons.Default.Groups, Modifier.weight(1f))
                MetricCard("التعويذات", "11 / 11", Icons.Default.Bolt, Modifier.weight(1f))
            }
        }
        item {
            Surface(color = Panel, shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("تحليل لقطة شاشة", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text("استورد صورة القرية أو شاشة الجيش لاستخراج النصوص والأرقام ومراجعتها.", color = Muted, fontSize = 12.sp)
                    Button(onClick = onImport, modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Bg)) {
                        Icon(Icons.Default.AddPhotoAlternate, null)
                        Spacer(Modifier.width(8.dp))
                        Text("اختيار صورة للتحليل", fontWeight = FontWeight.Bold)
                    }
                    Text(status, color = Green, fontSize = 12.sp)
                }
            }
        }
        item {
            Surface(color = Panel, shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("المهام", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    TaskRow("مراقبة الموارد", "قراءة الأرقام من لقطة الشاشة", true)
                    TaskRow("تحليل الجيش", "استخراج القوات والسعة", true)
                    TaskRow("تخطيط التطوير", "اقتراح أولويات البناء يدوياً", false)
                    TaskRow("تنفيذ هجمات أو نقرات تلقائية", "غير مدعوم في هذا الإصدار", false)
                }
            }
        }
        item { Text("الإصدار 0.1.0  •  Android 15", color = Muted, fontSize = 11.sp) }
    }
}

@Composable
fun ResourceTile(title: String, value: String, symbol: String, tint: Color, modifier: Modifier) {
    Surface(color = Panel2, shape = RoundedCornerShape(14.dp), modifier = modifier) {
        Column(Modifier.padding(13.dp)) {
            Text("$symbol  $title", color = tint, fontSize = 12.sp)
            Text(value, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 19.sp)
        }
    }
}

@Composable
fun MetricCard(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier) {
    Surface(color = Panel, shape = RoundedCornerShape(16.dp), modifier = modifier) {
        Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Icon(icon, null, tint = Gold)
            Text(title, color = Muted, fontSize = 12.sp)
            Text(value, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
    }
}

@Composable
fun TaskRow(title: String, subtitle: String, enabled: Boolean) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(if (enabled) Icons.Default.CheckCircle else Icons.Default.Info, null, tint = if (enabled) Green else Muted)
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Text(subtitle, fontSize = 11.sp, color = Muted)
        }
        Text(if (enabled) "متاح" else "لاحقاً", color = if (enabled) Green else Muted, fontSize = 11.sp)
    }
}

@Composable
fun AnalysisScreen(padding: PaddingValues, extracted: String, status: String, onImport: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(padding).padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("تحليل الشاشة", color = Gold, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text(status, color = Muted, fontSize = 13.sp)
        Button(onClick = onImport, colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Bg)) {
            Icon(Icons.Default.ImageSearch, null); Spacer(Modifier.width(8.dp)); Text("استيراد لقطة شاشة")
        }
        Surface(color = Panel, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth().weight(1f)) {
            Column(Modifier.padding(14.dp)) {
                Text("النص المستخرج", fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(10.dp))
                if (extracted.isBlank()) Text("لم يتم استخراج نص بعد.", color = Muted)
                else Text(extracted, color = Color.White, fontSize = 13.sp)
            }
        }
        Text("قد يخطئ OCR في قراءة الأرقام؛ راجع النتائج قبل اعتمادها.", color = Muted, fontSize = 11.sp)
    }
}

@Composable
fun SettingsScreen(padding: PaddingValues) {
    var notifications by remember { mutableStateOf(true) }
    var confirm by remember { mutableStateOf(true) }
    Column(Modifier.fillMaxSize().padding(padding).padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("الإعدادات", color = Gold, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Surface(color = Panel, shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(16.dp)) {
                SettingSwitch("إشعارات التحليل", notifications) { notifications = it }
                HorizontalDivider(color = Panel2)
                SettingSwitch("مراجعة النتائج قبل اعتمادها", confirm) { confirm = it }
            }
        }
        Surface(color = Panel, shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("حول التطبيق", fontWeight = FontWeight.Bold)
                Text("COC AUTO BOT 0.1.0", color = Gold)
                Text("مساعد لتحليل لقطات الشاشة ومتابعة بيانات القرية. لا يتحكم باللعبة ولا ينفذ هجمات أو نقرات تلقائية.", color = Muted, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun SettingSwitch(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, modifier = Modifier.weight(1f), fontSize = 13.sp)
        Switch(checked, onChange)
    }
}
